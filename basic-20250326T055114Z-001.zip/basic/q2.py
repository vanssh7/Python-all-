a = int(input("Enter the marks of first subject"))
b = int(input("Enter the marks of second subject"))
c = int(input("Enter the marks of third subject"))
d = int(input("Enter the marks of fourth subject"))
e = int(input("Enter the marks of fifth subject"))
avg=(a+b+c+d+e)/5
print(f"The avergae of the makrs is {avg}")