a =1
b=9 
c=a
a=b
b=c 
print(f"After spawing a = {a} b ={b}")