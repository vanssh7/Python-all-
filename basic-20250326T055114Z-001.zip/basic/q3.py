c = int(input("Enter the temperature in celsius"))
f = (9/5*c)+32
print(f"The temperature in fahrenheit = {f}")