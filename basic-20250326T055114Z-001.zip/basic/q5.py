dollar = int(input("Enter the amount in dollars"))
rupee = dollar*80
print(f"The amount in rupees is {rupee}")