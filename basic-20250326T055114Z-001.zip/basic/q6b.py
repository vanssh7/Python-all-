a=1
b=9
a=a+b
b=a-b
a=a-b
print(f"After spawing a = {a} b ={b}")