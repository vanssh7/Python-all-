a =int(input("Enter th radius of the circle"))
perimeter = 2*3.14*a
area = 3.14*a*a
print(f"The perimeter of the circle is {perimeter} and the area of the circle is {area}")