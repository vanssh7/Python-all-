list =["hello" ,"hi", "bye" ,"please"]
set =set()
for i in list:
    set.add(i.upper())
   
print(f"The set in uppercase is {set}")
