date1 =(15,11,2005)
date2=(25,2,2025)
day1,month1,year1=date1
a=day1
print(a)