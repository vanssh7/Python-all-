a = int(input("Enter the terms upto which you want the series"))
print("The series in reverse is :")
for i in range (a,0,-1):
    print(i,end =" ")