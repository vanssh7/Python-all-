a = int(input("Enter the number of which the table you want"))
print(f"The table of {a} is")
for i in range (1,11):
    print(a*i)