d ={'hello':1}
if not d :
    print("Empty dictonary")
else:
    print("Not an empty dictionary")