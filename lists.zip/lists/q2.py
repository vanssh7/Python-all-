list =[]
def square(l):
    l =[]
    j=[]
    n = int(input("Enter the range"))
    for i in range (n):
        l.append((int(input("Enter the values of the list"))))
        a=l[i]
        
        f=a*a
        #print("The list of square of numbers is")
        j.append(f)
    print(j)
square(list)
