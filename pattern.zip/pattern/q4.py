
for i in range(1,6,1):
    for a in range(6-i,0,-1):
        print(" ", end=" ")
    for j in range(1,i+1,1):
        print(j, end = "   ")
    print("\n")