b = int(input("Ënter the range"))
for i in range (1,b+1) :
   for j in range (65,65+i):
      a=chr(j)
      print(a,end=" ")
      print("\n")
