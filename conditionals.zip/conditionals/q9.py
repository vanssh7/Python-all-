a= int(input("Enter a number"))
if(a>0):
    print(f"the absolute value of |a| is {a} ")
else:
    print(f"The absolute value of |a| is {-a}")