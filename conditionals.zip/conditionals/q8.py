a=int(input("Enter the first angle of a triangle"))
b=int(input("Enter the second angle of a triangle"))
c=int(input("Enter the third angle of a triangle"))
if(a+b+c==180):
    print("the triangle is valid")
else:
    print("the triangle is not valid")