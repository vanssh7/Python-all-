year=int(input("Enter a year"))
if(year%4==0):
    print("leap year")
else:
    print("Not a leap year")