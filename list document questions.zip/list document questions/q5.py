list =[]
def upper(l):
    l =["hello","bye","Python","how","hey"]
    g=[]
    for i in range(len(l)):
        f=l[i].upper()
        g.append(f)
    print(g)
       
upper(list)
        
